#ifndef __DETERMINE_DIRE_H_
#define __DETERMINE_DIRE_H_

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <math.h>
#include <linux/input.h>
#include "main.h"
#endif